import { Data, animate, Override, Animatable } from 'framer'

const data = Data({
  scale: Animatable(1),
  password: '',
})

export const Key: Override = props => {
  let keyCharacter = props.children[0].props.children[0].props.text
  return {
    onTap() {
      let newPassword = data.password
      newPassword += keyCharacter + ' '
      data.password = newPassword
    },
  }
}

export const passwordString: Override = props => {
  return {
    text: data.password,
  }
}
