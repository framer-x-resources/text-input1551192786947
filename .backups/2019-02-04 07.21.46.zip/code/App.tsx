import { Data, animate, Override, Animatable } from 'framer'

const data = Data({
  scale: Animatable(1),
  password: 'Password',
  inputOpacity: '0.33',
})

export const Key: Override = props => {
  //   let keyCharacter = props.children[0].props.children[0].props.text
  // console.log('props', keyCharacter)
  return {
    onTap() {
      let newPassword = data.password
      //   newPassword += keyCharacter + ' '
      newPassword += '• '
      data.password = newPassword
      // if ((data.password = newPassword)) {
      //   data.loginbuttonOpacity = '1'
      // }
    },
  }
}

export const passwordString: Override = props => {
  return {
    text: data.password,
    opacity: data.inputOpacity,
  }
}
